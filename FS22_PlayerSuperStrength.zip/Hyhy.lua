Hyhy = {}; 

Player.MAX_PICKABLE_OBJECT_MASS = 9999;

function Hyhy:loadMap(name) 
end; 

function Hyhy:deleteMap()
end; 

function Hyhy:mouseEvent(posX, posY, isDown, isUp, button) 
end; 

function Hyhy:keyEvent(unicode, sym, modifier, isDown) 
end; 

function Hyhy:update(dt) 
end; 

function Hyhy:draw(Hyhy)
end; 

addModEventListener(Hyhy);