Ce fichier comprend 79 Radios françaises.


Pour avoir les radios vous devez suivre l'une des solutions ci-dessous : 

[STEAM]
1/ Ouvrir l'explorateur Windows
2/ Allez dans "Ce PC"
3/ Ce rentre dans le disque d'instalation de Farming Simulator 22
4/ Ouvrir le dossier "Programmes (x86)" (Uniquement si instalation sur le Disque C)
5/ Ouvrir le dossier "Steam"
6/ Ouvrir le dossier 'steamapps"
7/ Ouvrir le dossier 'common"
8/ Ouvrir le dossier 'Farming Simulator 22"
9/ Ouvrir le dossier 'data"
10/ Ouvrir le dossier 'music"
11/ Remplacer le fichier "streamingInternetRadios.xml"

[GIANTS]
1/ Ouvrir l'explorateur Windows
2/ Allez dans "Documents"
3/ Ouvrir le dossier "My Games"
4/ Ouvrir le dossier 'FarmingSimulator2022"
5/ Ouvrir le dossier 'music"
6/ Remplacer le fichier "streamingInternetRadios.xml"







Au passage, si vous souhaitez me soutenir : 
https://www.buymeacoffee.com/jameslebavard





Si vous souhaitez ajouter des radios ou si vous rencontrez le moindre souucis, vous pouvez m'ajouter sur Discord : JamesLeBavard#1710


#LEBAVARD


Ne pas réuploader le fichier sans mon autorisation, demande d'autorisation par mail : 
jameslebavard@gmail.com



