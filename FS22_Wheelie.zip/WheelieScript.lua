WheelieScript = {};

function WheelieScript:RotateVehicle(Vehicle,x,y,z)
	local Rx,Ry,Rz = localDirectionToWorld(Vehicle.rootNode,x,y,z);
	setAngularVelocity(Vehicle.rootNode,Rx,Ry,Rz);
end;

function WheelieScript:registerActionEvents()
	if self.isClient then
		WheelieScript.events = {};
		local valid, eventId = g_inputBinding:registerActionEvent(InputAction.AXIS_RUN, InputBinding.NO_EVENT_TARGET, WheelieScript.WheelieEvent, false, true, false, true);
		if valid then
			table.insert(WheelieScript.events, eventId);
			g_inputBinding:setActionEventText(eventId, "Wheelie");
			g_inputBinding:setActionEventTextVisibility(eventId, true);
			g_inputBinding:setActionEventTextPriority(eventId, GS_PRIO_VERYLOW);
		end;
	end;
end;

function WheelieScript:loadMap(savegame)
	if g_currentMission:getIsClient() then
		Enterable.onRegisterActionEvents = Utils.appendedFunction(Enterable.onRegisterActionEvents, WheelieScript.registerActionEvents);
	end;
end;

function WheelieScript:WheelieEvent(actionName, keyStatus, arg3, arg4, arg5)
end;

local InWheelie = false;
local RenderWarning = false;

function WheelieScript:draw()
	if RenderWarning == true then

	setTextColor(1,0.1,0.1,1);

	local fontSize = g_gameSettings:getValue("uiScale") * 0.025;
	local TextString = "To Perform a wheelie, please stop your vehicle.";
	local posX = 0.5;
	local posY = 0.1;

	local width = getTextWidth(fontSize, TextString);
    posX = posX - width/2

	renderText(posX, posY, fontSize, TextString);
  end;
end

function WheelieScript:WheelieUpdate()	
	local CurrentSpeed = g_currentMission.controlledVehicle:getLastSpeed();
	if CurrentSpeed > 1 and InWheelie == true then 
		local Vector = CurrentSpeed/10;
		if Vector > 0.7 then Vector = 0.7 end;
		WheelieScript:RotateVehicle(g_currentMission.controlledVehicle,-Vector,0,0);
	end;
end;

function WheelieScript:update()	
	if g_currentMission.controlledVehicle and InWheelie == false and Input.isKeyPressed(Input.KEY_lshift) and g_currentMission.controlledVehicle:getLastSpeed() < 1 then
	    InWheelie = true;
		RenderWarning = false;
	end;

	if g_currentMission.controlledVehicle and InWheelie == false and Input.isKeyPressed(Input.KEY_lshift) and g_currentMission.controlledVehicle:getLastSpeed() > 1 then
		RenderWarning = true;
	end;
	if Input.isKeyPressed(Input.KEY_lshift) == false then RenderWarning = false; end;

	if InWheelie == true and Input.isKeyPressed(Input.KEY_lshift) == false then InWheelie = false; end; 

	if g_currentMission.controlledVehicle then WheelieScript:WheelieUpdate(); end;
	if g_currentMission.controlledVehicle == nil then InWheelie = false; RenderWarning = false; end;
end;

addModEventListener(WheelieScript);