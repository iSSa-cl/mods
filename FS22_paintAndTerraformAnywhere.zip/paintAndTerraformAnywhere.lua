-- paintAnywhere 
-- by modelleicher 28.11.2021
-- allows to paint ground and foliage anywhere not just owned places as long as you have permission to do so (in Multiplayer)

paintAndTerraformAnywhere = {};

function paintAndTerraformAnywhere.verifyAccess(self, superFunc, a, b, c)
	local returnValue = superFunc(self, a, b, c);
	if self:hasPlayerPermission() then
		returnValue = nil;
	end;
	return returnValue;
end;
ConstructionBrush.verifyAccess = Utils.overwrittenFunction(ConstructionBrush.verifyAccess, paintAndTerraformAnywhere.verifyAccess);

function paintAndTerraformAnywhere.isModificationAreaOnOwnedLand(...)
	return true
end
Landscaping.isModificationAreaOnOwnedLand = Utils.overwrittenFunction(Landscaping.isModificationAreaOnOwnedLand, paintAndTerraformAnywhere.isModificationAreaOnOwnedLand);